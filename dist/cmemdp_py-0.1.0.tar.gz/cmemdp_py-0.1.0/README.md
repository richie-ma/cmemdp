# cme_mpd
Clean and Analyze Chicago Mercantile Exchange Market Data in Python
